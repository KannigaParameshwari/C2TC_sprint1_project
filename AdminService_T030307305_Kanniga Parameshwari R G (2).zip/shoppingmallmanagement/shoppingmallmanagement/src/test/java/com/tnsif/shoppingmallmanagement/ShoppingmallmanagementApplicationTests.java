package com.tnsif.shoppingmallmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingmallmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
