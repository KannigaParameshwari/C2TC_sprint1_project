package com.tnsif.shoppingmallmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingmallmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingmallmanagementApplication.class, args);
	}

}
